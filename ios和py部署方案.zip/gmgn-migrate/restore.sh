#!/bin/bash
#
# restore.sh —— 在【新服务器】上恢复 GMGN 部署
#
# 前提：
#   - 新服务器已装 Python 3.10+, Node 20+, GMGN cli, sqlite3
#   - 已 git clone 代码到 ~/gmgn-backend
#   - 已建好 venv 并装好 requirements
#   - 已解压 backup tarball 到当前目录
#
# 用法（在解压后的备份目录下跑）：
#   bash restore.sh
#

set -e

GMGN_DIR="$HOME/gmgn-backend"
BACKUP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "============================================"
echo " GMGN Backend 恢复"
echo " 备份来源: $BACKUP_DIR"
echo " 目标路径: $GMGN_DIR"
echo "============================================"

# ---------- 前置检查 ----------
echo ""
echo "[1/7] 前置检查..."

errors=0

if [ ! -d "$GMGN_DIR" ]; then
    echo "❌ 找不到 $GMGN_DIR（先 git clone 代码）"
    errors=$((errors+1))
fi

if [ ! -f "$GMGN_DIR/main.py" ]; then
    echo "❌ $GMGN_DIR 不像 GMGN 项目（没有 main.py）"
    errors=$((errors+1))
fi

if [ ! -d "$GMGN_DIR/venv" ]; then
    echo "❌ 没找到 venv，请先："
    echo "   cd $GMGN_DIR && python3 -m venv venv && source venv/bin/activate && pip install -r requirements.txt"
    errors=$((errors+1))
fi

if ! command -v gmgn-cli &> /dev/null; then
    echo "❌ gmgn-cli 没装，请先：sudo npm install -g gmgn-cli"
    errors=$((errors+1))
fi

if ! command -v sqlite3 &> /dev/null; then
    echo "❌ sqlite3 没装，请先：sudo apt install sqlite3"
    errors=$((errors+1))
fi

if [ ! -f "$BACKUP_DIR/gmgn.db" ]; then
    echo "❌ 备份目录没有 gmgn.db"
    errors=$((errors+1))
fi

if [ "$errors" -gt 0 ]; then
    echo ""
    echo "前置检查失败，先解决上面的问题再跑 restore.sh"
    exit 1
fi

echo "    ✓ 所有前置检查通过"

# ---------- 处理后端 .env (API_TOKEN) ----------
echo ""
echo "[2/7] 处理后端 .env (API_TOKEN)..."

if [ -f "$GMGN_DIR/.env" ]; then
    echo "    ⚠️  $GMGN_DIR/.env 已存在"
    read -p "    覆盖？[y/N]: " confirm
    if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
        echo "    跳过"
        SKIP_ENV=1
    fi
fi

if [ -z "$SKIP_ENV" ]; then
    echo ""
    echo "    选择 API_TOKEN 处理方式："
    echo "      1) 用备份里的 token（保持跟老服务器一致，iOS 不用改）"
    echo "      2) 重新随机生成（iOS 要重新设 token）"
    read -p "    选择 [1/2，默认 1]: " token_choice
    token_choice=${token_choice:-1}

    if [ "$token_choice" = "1" ]; then
        if [ -f "$BACKUP_DIR/.env" ]; then
            cp "$BACKUP_DIR/.env" "$GMGN_DIR/.env"
            echo "    ✓ 已用备份的 .env"
        else
            echo "    ⚠️  备份里没有 .env，回退到随机生成"
            token_choice=2
        fi
    fi

    if [ "$token_choice" = "2" ]; then
        # 生成 32 字节随机 token
        NEW_TOKEN=$(openssl rand -hex 32)
        echo "API_TOKEN=$NEW_TOKEN" > "$GMGN_DIR/.env"
        chmod 600 "$GMGN_DIR/.env"
        echo "    ✓ 已生成新 token"
        echo ""
        echo "    🔑 新 API_TOKEN（保存好，iOS 设置页要用）："
        echo "    $NEW_TOKEN"
        echo ""
    fi
fi

# ---------- 处理 GMGN cli .env ----------
echo ""
echo "[3/7] 处理 GMGN cli .env..."

mkdir -p "$HOME/.config/gmgn"
if [ -f "$HOME/.config/gmgn/.env" ]; then
    echo "    ⚠️  ~/.config/gmgn/.env 已存在"
    read -p "    覆盖？[y/N]: " confirm
    if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
        echo "    跳过"
        SKIP_GMGN_ENV=1
    fi
fi

if [ -z "$SKIP_GMGN_ENV" ]; then
    if [ -f "$BACKUP_DIR/gmgn-cli.env" ]; then
        cp "$BACKUP_DIR/gmgn-cli.env" "$HOME/.config/gmgn/.env"
        chmod 600 "$HOME/.config/gmgn/.env"
        echo "    ✓ 已恢复 GMGN cli .env"
    else
        echo "    ⚠️  备份里没有 gmgn-cli.env，需要手动配 GMGN API_KEY:"
        echo "       echo 'GMGN_API_KEY=你的key' > ~/.config/gmgn/.env"
        echo "       chmod 600 ~/.config/gmgn/.env"
    fi
fi

# 验证 cli 能跑
if ! gmgn-cli market trending --chain eth --limit 1 --raw &> /dev/null; then
    echo "    ⚠️  gmgn-cli 测试调用失败，检查 ~/.config/gmgn/.env 里的 API_KEY"
fi

# ---------- 处理数据库 ----------
echo ""
echo "[4/7] 处理数据库..."

if [ -f "$GMGN_DIR/gmgn.db" ]; then
    echo "    ⚠️  $GMGN_DIR/gmgn.db 已存在"
    read -p "    备份当前数据库为 .bak 后覆盖？[y/N]: " confirm
    if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ]; then
        mv "$GMGN_DIR/gmgn.db" "$GMGN_DIR/gmgn.db.bak.$(date +%s)"
        echo "    旧数据库已备份"
    else
        echo "    跳过数据库恢复（保留当前 gmgn.db）"
        SKIP_DB=1
    fi
fi

if [ -z "$SKIP_DB" ]; then
    echo ""
    echo "    选择数据库恢复模式："
    echo "      1) 恢复老数据（保留聪明钱、储物袋、所有历史信号）← 推荐"
    echo "      2) 空库启动（从零开始）"
    read -p "    选择 [1/2，默认 1]: " db_choice
    db_choice=${db_choice:-1}

    if [ "$db_choice" = "1" ]; then
        cp "$BACKUP_DIR/gmgn.db" "$GMGN_DIR/gmgn.db"
        echo "    ✓ 已恢复老数据库"

        # 跑一次 init_db 触发可能的 schema 迁移
        echo "    跑 schema 迁移..."
        cd "$GMGN_DIR"
        ./venv/bin/python3 -c "
import refresh
conn = refresh.init_db()
conn.close()
print('    ✓ schema 迁移完成')
" 2>&1 | sed 's/^/    /'
        cd - > /dev/null
    else
        echo "    空库模式：让后端首次启动时自动 init_db 创建空库"
    fi
fi

# ---------- 装 systemd unit ----------
echo ""
echo "[5/7] 装 systemd unit..."

if [ ! -d "$BACKUP_DIR/systemd" ]; then
    echo "    ⚠️  备份里没有 systemd 目录，要手动配"
else
    for unit in gmgn-api.service gmgn-refresh.service gmgn-refresh.timer; do
        if [ -f "$BACKUP_DIR/systemd/$unit" ]; then
            sudo cp "$BACKUP_DIR/systemd/$unit" "/etc/systemd/system/$unit"
            echo "    ✓ $unit"
        else
            echo "    ⚠️  $unit 在备份里缺失"
        fi
    done

    # 处理 unit 里写死的用户名 / 路径
    # 老服务器用户是 admin，路径是 /home/admin/gmgn-backend
    # 如果新服务器用户名不一样，要改
    if [ "$USER" != "admin" ] || [ "$HOME" != "/home/admin" ]; then
        echo ""
        echo "    ⚠️  当前用户/路径跟备份里的不一样："
        echo "       备份预期：admin / /home/admin/gmgn-backend"
        echo "       当前实际：$USER / $HOME/gmgn-backend"
        echo "    自动替换 unit 文件..."
        for unit in gmgn-api.service gmgn-refresh.service; do
            sudo sed -i "s|User=admin|User=$USER|g" "/etc/systemd/system/$unit"
            sudo sed -i "s|/home/admin/gmgn-backend|$HOME/gmgn-backend|g" "/etc/systemd/system/$unit"
        done
        echo "    ✓ 已替换"
    fi

    sudo systemctl daemon-reload
    sudo systemctl enable gmgn-api.service gmgn-refresh.timer
    echo "    ✓ systemd unit 已 enable（会开机自启）"
fi

# ---------- 启动服务 ----------
echo ""
echo "[6/7] 启动服务..."

sudo systemctl restart gmgn-api.service
sleep 3

if systemctl is-active gmgn-api.service > /dev/null; then
    echo "    ✓ gmgn-api 已启动"
else
    echo "    ❌ gmgn-api 启动失败"
    echo "    看错误："
    sudo journalctl -u gmgn-api -n 30 --no-pager
    exit 1
fi

sudo systemctl start gmgn-refresh.timer
echo "    ✓ gmgn-refresh.timer 已启动"

# 立刻触发一次 refresh 测试
echo "    立刻触发一次 refresh 测试..."
sudo systemctl start gmgn-refresh.service
echo "    refresh 已触发，正在后台跑..."

# ---------- 总结 ----------
echo ""
echo "[7/7] 完成"
echo ""
echo "============================================"
echo "✅ 恢复完成"
echo ""

# 显示当前状态
API_TOKEN=$(grep API_TOKEN "$GMGN_DIR/.env" 2>/dev/null | cut -d= -f2)
PORT=8000
LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}')

echo "服务地址: http://$LOCAL_IP:$PORT"
echo "健康检查: curl -H \"Authorization: Bearer $API_TOKEN\" http://localhost:$PORT/healthz"
echo ""
echo "iOS 设置页要做的事："
echo "  Server URL: http://$LOCAL_IP:$PORT"
echo "  API Token:  (见 $GMGN_DIR/.env，或上面 token_choice=2 时显示的新 token)"
echo "  点【测试连接】→ 点【生效】"
echo ""
echo "下一步："
echo "  bash healthcheck.sh   # 跑完整健康检查"
echo "============================================"
