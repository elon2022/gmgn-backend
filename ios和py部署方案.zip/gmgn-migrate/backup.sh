#!/bin/bash
#
# backup.sh —— 在【老服务器】上备份当前 GMGN 部署
# 产物：~/gmgn-backup-YYYYMMDD-HHMMSS.tar.gz，包含：
#   - gmgn.db（数据库）
#   - .env（API_TOKEN）
#   - ~/.config/gmgn/.env（GMGN cli 的 API_KEY）
#   - requirements.txt
#   - 三个 systemd unit 文件
#   - restore.sh / healthcheck.sh（一并打进去，新服务器解压即用）
#
# 用法：
#   bash backup.sh
#

set -e

GMGN_DIR="$HOME/gmgn-backend"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="$HOME/gmgn-backup-$TIMESTAMP"
BACKUP_TAR="$HOME/gmgn-backup-$TIMESTAMP.tar.gz"

echo "============================================"
echo " GMGN Backend 备份"
echo " 目标包：$BACKUP_TAR"
echo "============================================"

# ---------- 前置检查 ----------
echo ""
echo "[1/7] 前置检查..."

if [ ! -d "$GMGN_DIR" ]; then
    echo "❌ 找不到 $GMGN_DIR"
    exit 1
fi

if [ ! -f "$GMGN_DIR/gmgn.db" ]; then
    echo "❌ 找不到 $GMGN_DIR/gmgn.db"
    exit 1
fi

if [ ! -f "$GMGN_DIR/.env" ]; then
    echo "⚠️  没找到 $GMGN_DIR/.env（API_TOKEN 不存在？继续打包，新服务器要手动设）"
fi

if [ ! -f "$HOME/.config/gmgn/.env" ]; then
    echo "⚠️  没找到 ~/.config/gmgn/.env（GMGN cli API_KEY 不存在？）"
fi

mkdir -p "$BACKUP_DIR"

# ---------- 暂停 timer 防止备份期间数据写入 ----------
echo ""
echo "[2/7] 暂停 gmgn-refresh.timer（备份期间不让 timer 触发）..."
TIMER_WAS_ACTIVE=0
if systemctl is-active gmgn-refresh.timer &> /dev/null; then
    sudo systemctl stop gmgn-refresh.timer
    TIMER_WAS_ACTIVE=1
    echo "    timer 已暂停"
else
    echo "    timer 当前不是 active 状态，跳过"
fi

# 等 5 秒确保正在跑的 refresh.service 跑完
sleep 5

# ---------- 备份数据库 ----------
echo ""
echo "[3/7] 备份数据库..."

# 用 sqlite3 .backup 命令做"在线热备份"，比直接 cp 安全（避免拷到一半）
sqlite3 "$GMGN_DIR/gmgn.db" ".backup $BACKUP_DIR/gmgn.db"
DB_SIZE=$(du -h "$BACKUP_DIR/gmgn.db" | cut -f1)
echo "    数据库已备份（$DB_SIZE）"

# ---------- 备份配置文件 ----------
echo ""
echo "[4/7] 备份配置文件..."

# 后端 .env
if [ -f "$GMGN_DIR/.env" ]; then
    cp "$GMGN_DIR/.env" "$BACKUP_DIR/.env"
    echo "    后端 .env 已备份"
fi

# GMGN cli 配置
if [ -f "$HOME/.config/gmgn/.env" ]; then
    cp "$HOME/.config/gmgn/.env" "$BACKUP_DIR/gmgn-cli.env"
    echo "    GMGN cli .env 已备份"
fi

# requirements.txt
if [ -f "$GMGN_DIR/requirements.txt" ]; then
    cp "$GMGN_DIR/requirements.txt" "$BACKUP_DIR/requirements.txt"
    echo "    requirements.txt 已备份"
fi

# ---------- 备份 systemd unit ----------
echo ""
echo "[5/7] 备份 systemd unit..."

mkdir -p "$BACKUP_DIR/systemd"
for unit in gmgn-api.service gmgn-refresh.service gmgn-refresh.timer; do
    if [ -f "/etc/systemd/system/$unit" ]; then
        sudo cp "/etc/systemd/system/$unit" "$BACKUP_DIR/systemd/$unit"
        sudo chown $USER:$USER "$BACKUP_DIR/systemd/$unit"
        echo "    $unit"
    else
        echo "    ⚠️  /etc/systemd/system/$unit 不存在"
    fi
done

# ---------- 复制 restore.sh 和 healthcheck.sh 到包里 ----------
echo ""
echo "[6/7] 把 restore.sh / healthcheck.sh 一起打包..."

# 这两个脚本应该和 backup.sh 在同一目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for script in restore.sh healthcheck.sh; do
    if [ -f "$SCRIPT_DIR/$script" ]; then
        cp "$SCRIPT_DIR/$script" "$BACKUP_DIR/$script"
        chmod +x "$BACKUP_DIR/$script"
    else
        echo "    ⚠️  $SCRIPT_DIR/$script 不存在，新服务器上要手动找"
    fi
done

# 写入元信息
cat > "$BACKUP_DIR/BACKUP_INFO.txt" <<EOF
GMGN Backup
============
备份时间: $(date)
源服务器: $(hostname) ($(hostname -I 2>/dev/null | head -1))
源用户: $USER
源路径: $GMGN_DIR

包含内容:
- gmgn.db                 SQLite 数据库
- .env                    后端 API_TOKEN
- gmgn-cli.env            GMGN cli 的 API_KEY（恢复到 ~/.config/gmgn/.env）
- requirements.txt        Python 依赖
- systemd/*.service       systemd unit 文件
- systemd/*.timer
- restore.sh              在新服务器上跑这个恢复
- healthcheck.sh          恢复后跑这个验证

数据库统计:
$(sqlite3 "$BACKUP_DIR/gmgn.db" "
SELECT 'trending_snapshots: ' || COUNT(*) FROM trending_snapshots;
SELECT 'tokens: ' || COUNT(*) FROM tokens;
SELECT 'radar_signals: ' || COUNT(*) FROM radar_signals;
SELECT 'radar_v2_signals: ' || COUNT(*) FROM radar_v2_signals;
SELECT 'storage_bag_signals: ' || COUNT(*) FROM storage_bag_signals;
SELECT 'watched_tokens: ' || COUNT(*) FROM watched_tokens;
SELECT 'smart_money: ' || COUNT(*) FROM smart_money;
" 2>/dev/null || echo "（无法读取统计，但数据库已备份）")
EOF

# ---------- 恢复 timer ----------
echo ""
echo "[7/7] 恢复 timer + 打包..."

if [ "$TIMER_WAS_ACTIVE" = "1" ]; then
    sudo systemctl start gmgn-refresh.timer
    echo "    timer 已恢复"
fi

# 打包
cd "$HOME"
tar -czf "$BACKUP_TAR" "$(basename "$BACKUP_DIR")"
TAR_SIZE=$(du -h "$BACKUP_TAR" | cut -f1)

# 清理临时目录
rm -rf "$BACKUP_DIR"

echo ""
echo "============================================"
echo "✅ 备份完成"
echo ""
echo "包文件: $BACKUP_TAR"
echo "大小:   $TAR_SIZE"
echo ""
echo "下一步："
echo "  scp $BACKUP_TAR admin@<新服务器IP>:~/"
echo "  ssh admin@<新服务器IP>"
echo "  cd ~ && tar -xzvf $(basename "$BACKUP_TAR") && cd $(basename "$BACKUP_DIR")"
echo "  bash restore.sh"
echo "============================================"
