#!/bin/bash
#
# healthcheck.sh —— 验证迁移后的部署是否健康
# 用法： bash healthcheck.sh
#

GMGN_DIR="$HOME/gmgn-backend"
PORT=8000
PASS_COUNT=0
FAIL_COUNT=0

PASS() { echo "  ✅ $1"; PASS_COUNT=$((PASS_COUNT+1)); }
FAIL() { echo "  ❌ $1"; FAIL_COUNT=$((FAIL_COUNT+1)); }
WARN() { echo "  ⚠️  $1"; }

echo "============================================"
echo " GMGN Backend 健康检查"
echo "============================================"

# ---------- 1. 文件 ----------
echo ""
echo "[1] 文件检查"

[ -d "$GMGN_DIR" ] && PASS "$GMGN_DIR 存在" || FAIL "$GMGN_DIR 不存在"
[ -f "$GMGN_DIR/main.py" ] && PASS "main.py 存在" || FAIL "main.py 缺失"
[ -f "$GMGN_DIR/gmgn.db" ] && PASS "gmgn.db 存在" || FAIL "gmgn.db 缺失"
[ -f "$GMGN_DIR/.env" ] && PASS ".env 存在" || FAIL ".env 缺失"
[ -d "$GMGN_DIR/venv" ] && PASS "venv 存在" || FAIL "venv 缺失"
[ -f "$HOME/.config/gmgn/.env" ] && PASS "GMGN cli .env 存在" || FAIL "GMGN cli .env 缺失"

# ---------- 2. 工具 ----------
echo ""
echo "[2] 工具检查"

if command -v gmgn-cli &> /dev/null; then
    VER=$(gmgn-cli --version 2>&1)
    PASS "gmgn-cli 已装（$VER）"
else
    FAIL "gmgn-cli 未装"
fi

if command -v sqlite3 &> /dev/null; then
    PASS "sqlite3 已装"
else
    FAIL "sqlite3 未装"
fi

PYTHON_VER=$("$GMGN_DIR/venv/bin/python3" --version 2>&1 | cut -d' ' -f2)
if [ -n "$PYTHON_VER" ]; then
    PASS "venv Python 可用（$PYTHON_VER）"
fi

# 测 cli 真能调用
if gmgn-cli market trending --chain eth --limit 1 --raw &> /dev/null; then
    PASS "gmgn-cli 可调用 GMGN 接口"
else
    FAIL "gmgn-cli 调用失败（API_KEY 错？）"
fi

# ---------- 3. systemd ----------
echo ""
echo "[3] systemd 服务"

if systemctl is-enabled gmgn-api.service &> /dev/null; then
    PASS "gmgn-api 开机自启"
else
    WARN "gmgn-api 未 enable，重启后不会自动启动"
fi

if systemctl is-active gmgn-api.service &> /dev/null; then
    PASS "gmgn-api 当前 active"
else
    FAIL "gmgn-api 未运行"
fi

if systemctl is-enabled gmgn-refresh.timer &> /dev/null; then
    PASS "gmgn-refresh.timer 开机自启"
else
    WARN "gmgn-refresh.timer 未 enable"
fi

if systemctl is-active gmgn-refresh.timer &> /dev/null; then
    PASS "gmgn-refresh.timer 当前 active"
else
    FAIL "gmgn-refresh.timer 未运行"
fi

# ---------- 4. 数据库 ----------
echo ""
echo "[4] 数据库"

if [ -f "$GMGN_DIR/gmgn.db" ]; then
    DB_SIZE=$(du -h "$GMGN_DIR/gmgn.db" | cut -f1)
    echo "  数据库大小：$DB_SIZE"

    # 看每张表行数
    echo "  表统计："
    sqlite3 "$GMGN_DIR/gmgn.db" "
SELECT '    trending_snapshots: ' || COUNT(*) FROM trending_snapshots;
SELECT '    tokens:             ' || COUNT(*) FROM tokens;
SELECT '    radar_signals:      ' || COUNT(*) FROM radar_signals;
SELECT '    radar_v2_signals:   ' || COUNT(*) FROM radar_v2_signals;
SELECT '    storage_bag_signals:' || COUNT(*) FROM storage_bag_signals;
SELECT '    watched_tokens:     ' || COUNT(*) FROM watched_tokens;
SELECT '    smart_money:        ' || COUNT(*) FROM smart_money;
" 2>/dev/null

    # 看最新 trending 快照时间
    LATEST_TS=$(sqlite3 "$GMGN_DIR/gmgn.db" "SELECT MAX(ts) FROM trending_snapshots" 2>/dev/null)
    if [ -n "$LATEST_TS" ]; then
        PASS "最新 trending 快照: $LATEST_TS"
    else
        WARN "trending_snapshots 是空的（如果是空库启动这正常，等 timer 跑一次后再看）"
    fi
fi

# ---------- 5. API ----------
echo ""
echo "[5] API 接口"

API_TOKEN=$(grep API_TOKEN "$GMGN_DIR/.env" 2>/dev/null | cut -d= -f2)

if [ -z "$API_TOKEN" ]; then
    FAIL "API_TOKEN 在 .env 里读不到"
else
    HEALTH_RESP=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$PORT/healthz" 2>/dev/null)
    if [ "$HEALTH_RESP" = "200" ]; then
        PASS "/healthz 返回 200"
    else
        FAIL "/healthz 返回 $HEALTH_RESP"
    fi

    TRENDING_RESP=$(curl -s -o /dev/null -w "%{http_code}" \
        -H "Authorization: Bearer $API_TOKEN" \
        "http://localhost:$PORT/api/v1/trending?chain=eth&limit=1")
    if [ "$TRENDING_RESP" = "200" ]; then
        PASS "/api/v1/trending 返回 200"
    elif [ "$TRENDING_RESP" = "401" ]; then
        FAIL "/api/v1/trending 返回 401（API_TOKEN 不对？）"
    else
        FAIL "/api/v1/trending 返回 $TRENDING_RESP"
    fi
fi

# ---------- 6. 网络 ----------
echo ""
echo "[6] 网络"

LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
echo "  本机 IP：$LOCAL_IP"
echo "  对外服务：http://$LOCAL_IP:$PORT"

# 测端口是否开
if ss -tln 2>/dev/null | grep -q ":$PORT "; then
    PASS "端口 $PORT 在监听"
else
    FAIL "端口 $PORT 没在监听"
fi

# ---------- 7. 最近的 refresh 日志 ----------
echo ""
echo "[7] 最近的 refresh 任务"
LAST_RUN=$(systemctl show gmgn-refresh.service -p ExecMainStartTimestamp --value 2>/dev/null)
if [ -n "$LAST_RUN" ] && [ "$LAST_RUN" != "n/a" ]; then
    PASS "最近一次 refresh: $LAST_RUN"
else
    WARN "refresh 还没跑过（如果刚装好，等几分钟）"
fi

# ---------- 总结 ----------
echo ""
echo "============================================"
TOTAL=$((PASS_COUNT + FAIL_COUNT))
echo " 总结：$PASS_COUNT/$TOTAL 通过"
if [ "$FAIL_COUNT" -gt 0 ]; then
    echo " ❌ $FAIL_COUNT 项失败，看上面的详情排查"
    exit 1
else
    echo " ✅ 全部通过"
    echo ""
    echo " iOS 端要做："
    echo "   设置 → Server URL: http://$LOCAL_IP:$PORT"
    echo "   设置 → API Token: 见 $GMGN_DIR/.env"
    echo "   测试连接 → 生效"
fi
echo "============================================"
