# GMGN Backend 迁移与部署方案

> 适用场景：把当前 GMGN 后端部署到一台新 Ubuntu 服务器（或重装当前服务器）。
>
> 文档版本：v1（2026-05-10）

---

## 一、新服务器最小要求

- Ubuntu 20.04 / 22.04 / 24.04（其他 Debian 系大概率也能跑）
- root / sudo 权限
- 至少 2GB 内存、5GB 磁盘
- 可访问外网（要拉 GMGN 接口、npm、GitHub）

---

## 二、迁移流程（10 步走完）

### Step 1：在【老服务器】上备份

把数据库 + 关键配置打包带走。

```bash
# 跑迁移仓库里的 backup.sh（脚本见 §三）
bash backup.sh
# 产物：~/gmgn-backup-YYYYMMDD-HHMMSS.tar.gz
```

打包内容：
- `gmgn.db`（数据库，含聪明钱地址簿、储物袋、所有信号）
- `.env`（API_TOKEN）
- `~/.config/gmgn/.env`（GMGN cli 的 API_KEY）
- `requirements.txt`
- 三个 systemd unit 文件

### Step 2：把备份传到新服务器

```bash
# 在老服务器
scp ~/gmgn-backup-*.tar.gz admin@<新服务器IP>:~/
```

### Step 3：在【新服务器】上准备账号

```bash
# 如果新服务器还没有 admin 用户
sudo adduser admin
sudo usermod -aG sudo admin

# 切到 admin 用户
su - admin
```

### Step 4：装系统依赖

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip git sqlite3 curl
```

### Step 5：装 Node.js + GMGN cli

```bash
# 装 Node.js 20.x（GMGN cli 要求）
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# 装 GMGN cli
sudo npm install -g gmgn-cli

# 验证
gmgn-cli --version    # 应该 ≥ 1.2.9
node --version        # 应该 v20.x.x
```

### Step 6：拉代码

```bash
cd ~

# 用 SSH（推荐，需先在新服务器生成 ssh key 加到 GitHub）
git clone git@github.com:elon2022/gmgn-backend.git

# 或用 token（不推荐，token 会留在 .git/config）
# git clone https://<TOKEN>@github.com/elon2022/gmgn-backend.git
```

> 关于 SSH key：在新服务器跑 `ssh-keygen -t ed25519`，把 `~/.ssh/id_ed25519.pub` 内容加到 https://github.com/settings/keys

### Step 7：装 Python venv + 依赖

```bash
cd ~/gmgn-backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
deactivate
```

### Step 8：恢复配置 + 数据

跑 `restore.sh`（脚本见 §四），交互式选数据模式：

```bash
cd ~
tar -xzvf gmgn-backup-*.tar.gz
cd gmgn-backup-*
bash restore.sh
```

restore.sh 会问：

1. **API_TOKEN 怎么处理**：
   - 用备份里的（保持跟老服务器一致；iOS 不用改）
   - 重新随机生成（老 iOS App 要重新设 token）

2. **GMGN cli .env 怎么处理**：
   - 用备份里的（API_KEY 已配好）
   - 跳过（你想手动配）

3. **数据库怎么处理**：
   - 恢复老数据（保留聪明钱、储物袋、历史信号）← 推荐
   - 空库启动（从零开始）

### Step 9：装 systemd unit + 启动

```bash
cd ~/gmgn-backup-*
sudo cp systemd/gmgn-api.service /etc/systemd/system/
sudo cp systemd/gmgn-refresh.service /etc/systemd/system/
sudo cp systemd/gmgn-refresh.timer /etc/systemd/system/

sudo systemctl daemon-reload
sudo systemctl enable --now gmgn-api.service
sudo systemctl enable --now gmgn-refresh.timer
```

### Step 10：健康检查

```bash
# 跑 healthcheck.sh（脚本见 §五）
bash ~/gmgn-backup-*/healthcheck.sh
```

输出全绿 = 迁移成功。

---

## 三、backup.sh（在老服务器上跑）

见同目录 `backup.sh` 文件。

---

## 四、restore.sh（在新服务器上跑）

见同目录 `restore.sh` 文件。

---

## 五、healthcheck.sh（迁移后验证）

见同目录 `healthcheck.sh` 文件。

---

## 六、iOS 端要做的事

迁移后需要把 iOS 指向新服务器。

打开 App → 调息（设置）→

1. **Server URL**：改成新服务器地址，例如 `http://<新IP>:8000`
2. **API Token**：
   - 如果 restore.sh 选了"用备份里的 token" → iOS 不用改
   - 如果 restore.sh 选了"重新生成 token" → 用新 token 替换
3. 点 **测试连接** → 显示 OK
4. 点 **生效**

---

## 七、迁移后第一周

观察这些事，确认运行正常：

```bash
# 看 timer 是否在跑
systemctl list-timers gmgn-refresh.timer

# 看最近的 refresh 日志
sudo journalctl -u gmgn-refresh -n 50 --no-pager

# 看数据是否在持续写入
sqlite3 ~/gmgn-backend/gmgn.db "SELECT chain, MAX(ts) FROM trending_snapshots GROUP BY chain"

# 看 API 是否健康
curl -H "Authorization: Bearer $API_TOKEN" http://localhost:8000/healthz
```

---

## 八、回滚

如果新服务器跑出问题想回到老服务器：

1. **不要在老服务器上停服务** — 老服务器一直保持运行，是你的"安全网"
2. iOS 改回老服务器地址即可
3. 新服务器排查问题不影响线上

---

## 九、安全注意事项

1. **API_TOKEN** 是 iOS ↔ 后端的唯一鉴权，必须保密
2. **GMGN cli 的 API_KEY**（在 `~/.config/gmgn/.env`）等同于你的 GMGN 账号
3. **GitHub PAT** 不要明文写在 git remote URL 里，用 SSH key 或 credential helper
4. 老服务器停用前确认新服务器跑稳了至少 24h

---

## 十、常见问题

**Q：备份能否在 timer 触发的瞬间跑？**

可以但不建议。backup.sh 会自动 `systemctl stop gmgn-refresh.timer` 暂停 timer，备份完恢复。

**Q：恢复老数据时遇到 schema 不一致怎么办？**

restore.sh 跑完会自动调用 `python3 refresh.py --init-only`（实际跑一次 refresh 触发 init_db 迁移）。如果数据库 schema 太老缺少新表/字段，迁移函数会自动补上。

**Q：迁移后聪明钱地址簿丢失？**

检查 restore.sh 是否选了"恢复老数据"。如果选了"空库启动"，数据全没了。

**Q：iOS 一直报 401 unauthorized？**

API_TOKEN 不一致。打开 iOS 设置页核对，或者跑：
```bash
cat ~/gmgn-backend/.env | grep API_TOKEN
```
对照 iOS 里填的值。
